<?php
session_start();
include 'includes/db.php';

$correo = mysqli_real_escape_string($conn, $_POST['correo']);
$password_ingresado = $_POST['password'];

// 1. Encriptamos la contraseña ingresada con MD5 para poder compararla
$password_md5 = md5($password_ingresado);

// 2. Buscamos al usuario que coincida con el correo Y la contraseña MD5
$query = "SELECT * FROM usuarios WHERE correo = '$correo' AND password = '$password_md5'";
$resultado = mysqli_query($conn, $query);

if (mysqli_num_rows($resultado) > 0) {
    $usuario = mysqli_fetch_assoc($resultado);
    
    // Guardamos los datos en la sesión
    $_SESSION['usuario_id'] = $usuario['id'];
    $_SESSION['nombre'] = $usuario['nombre'];
    $_SESSION['rol'] = $usuario['rol'];
    $_SESSION['correo'] = $usuario['correo']; // Esto quita el error de image_409c9a.png

    header("Location: dashboard.php");
} else {
    // Si no coincide, mandamos error
    header("Location: login.php?error=datos_incorrectos");
}
?>