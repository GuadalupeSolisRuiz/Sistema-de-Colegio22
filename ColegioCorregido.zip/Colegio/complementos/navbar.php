 <nav class="navbar navbar-custom d-flex justify-content-between mb-4">
            <span class="badge bg-purple-light text-purple p-2">
                Sesión: <span class="fw-bold"><?php echo $nombre_rol_texto; ?></span>
            </span>
            
            <div class="dropdown">
                <a href="#" class="d-flex align-items-center text-dark text-decoration-none dropdown-toggle" id="userMenu" data-bs-toggle="dropdown">
                    <img src="https://ui-avatars.com/api/?name=<?php echo $_SESSION['nombre']; ?>&background=6f42c1&color=fff" alt="" class="rounded-circle me-2" width="32">
                    <strong><?php echo $_SESSION['nombre']; ?></strong>
                </a>
                <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                    <li><a class="dropdown-item text-danger" href="includes/cerrar.php"><i class="bi bi-box-arrow-right me-2"></i>Cerrar Sesión</a></li>
                </ul>
            </div>
        </nav>
