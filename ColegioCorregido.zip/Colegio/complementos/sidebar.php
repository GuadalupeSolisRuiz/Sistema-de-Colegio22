<div class="sidebar d-flex flex-column p-3">
        <div class="d-flex align-items-center mb-4 text-white text-decoration-none">
            <i class="bi bi-mortarboard-fill fs-2 me-2"></i>
            <span class="fs-4 fw-bold">Colegio Inglés</span>
        </div>
        <hr>
        <ul class="nav nav-pills flex-column mb-auto">
            <li><a href="dashboard.php?seccion=inicio" class="nav-link <?php echo ($seccion=='inicio')?'active':''; ?>"><i class="bi bi-house-door me-2"></i> Inicio</a></li>
            
            <?php if($rol == 3): // ALUMNOS ?>
                <li><a href="dashboard.php?seccion=historial" class="nav-link <?php echo ($seccion=='historial')?'active':''; ?>"><i class="bi bi-journal-check me-2"></i> Historial Académico</a></li>
                <li><a href="dashboard.php?seccion=cita_plantel" class="nav-link <?php echo ($seccion=='cita_plantel')?'active':''; ?>"><i class="bi bi-calendar-plus me-2"></i> Solicitar Cita</a></li>
            <?php endif; ?>

            <?php if($rol == 2 || $rol == 1): // MAESTROS Y SISTEMAS ?>
                <li><a href="dashboard.php?seccion=captura" class="nav-link <?php echo ($seccion=='captura')?'active':''; ?>"><i class="bi bi-pencil-square me-2"></i> Captura de Notas</a></li>
                <li><a href="dashboard.php?seccion=gestion_citas" class="nav-link <?php echo ($seccion=='gestion_citas')?'active':''; ?>"><i class="bi bi-calendar-check me-2"></i> Gestión de Citas</a></li>
            <?php endif; ?>

            <?php if($rol == 1): // SOLO SISTEMAS ?>
                <li><a href="dashboard.php?seccion=gestion_usuarios" class="nav-link <?php echo ($seccion=='gestion_usuarios')?'active':''; ?>"><i class="bi bi-gear me-2"></i> Gestión de Usuarios</a></li>
            <?php endif; ?>
        </ul>
    </div>