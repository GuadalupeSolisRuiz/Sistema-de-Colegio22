<?php
// 1. Iniciamos la sesión
session_start();

// 2. Incluimos la conexión y la lógica de consultas
include 'includes/db.php'; 
include 'includes/consultas_dashboard.php'; 

// Control de navegación
$seccion = isset($_GET['seccion']) ? $_GET['seccion'] : 'inicio';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Sistema Escolar | Dashboard</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/diseño.css">
</head>
<body>

<div class="d-flex">
<?php include  'complementos/sidebar.php'; ?>

    <div class="main-content w-100">
       <?php include  'complementos/navbar.php'; ?>
        <div class="container-fluid">
            <?php
            switch ($seccion) {
                case 'gestion_usuarios':
                    if($rol == 1) include 'vistas/usuarios.php';
                    break;
                case 'captura':
                    if($rol == 1 || $rol == 2) include 'vistas/captura_notas.php';
                    break;
                case 'cita_plantel':
                    include 'vistas/citas.php';
                    break;
                case 'editar_usuario':
                    if($rol == 1) include 'vistas/editar_usuario_form.php';
                 break;
                case 'gestion_citas':
                    if($rol == 1 || $rol == 2) include 'vistas/gestion_citas.php';
                    break;
                case 'historial':
                    include 'vistas/inicio_alumno.php';
                    break;
                default:
                    include 'vistas/inicio_alumno.php';
                    break;
            }
            ?>
        </div>
    </div>
</div>

<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>