<?php
session_start();
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // LÍNEA DE PRUEBA: Si esto aparece, el archivo sí se está ejecutando
    echo "Intentando eliminar el ID: " . $id; 

    $sql = "DELETE FROM usuarios WHERE id = '$id'";

    if (mysqli_query($conn, $sql)) {
        header("Location: ../dashboard.php?seccion=gestion_usuarios&status=deleted");
        exit();
    } else {
        // Esto te dirá si MySQL bloqueó la eliminación por la Llave Foránea
        die("Error de MySQL: " . mysqli_error($conn));
    }
} else {
    echo "No se recibió ningún ID";
}
?>