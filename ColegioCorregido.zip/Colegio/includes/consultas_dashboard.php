<?php
// includes/consultas_dashboard.php

// 1. Verificamos la sesión (Seguridad)
if(!isset($_SESSION['usuario_id'])) { 
    header("Location: login.php"); 
    exit();
}

// 2. CONSULTA: Obtenemos datos frescos del usuario y su nombre de rol
$id_user = $_SESSION['usuario_id'];
$query_user = "SELECT u.*, r.nombre_rol 
               FROM usuarios u 
               INNER JOIN roles r ON u.rol = r.id_rol 
               WHERE u.id = '$id_user'";

$res_user = mysqli_query($conn, $query_user);

if($res_user && mysqli_num_rows($res_user) > 0) {
    $datos_usuario = mysqli_fetch_assoc($res_user);
    $rol = $datos_usuario['rol']; 
    $nombre_rol_texto = $datos_usuario['nombre_rol']; 
} else {
    // Si por alguna razón no hay datos, cerramos sesión por seguridad
    session_destroy();
    header("Location: login.php");
    exit();
}
?>