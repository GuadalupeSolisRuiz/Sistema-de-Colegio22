<?php
session_start();
include 'db.php'; // Conectamos a la base de datos

// Verificamos que el botón del formulario haya sido presionado
if (isset($_POST['btn_actualizar'])) {
    
    // 1. Recibimos los datos del formulario (usando los 'name' que pusimos en el form)
    // Usamos mysqli_real_escape_string por seguridad contra inyección SQL
    $id = mysqli_real_escape_string($conn, $_POST['id_usuario']);
    $nombre = mysqli_real_escape_string($conn, $_POST['nombre']);
    $correo = mysqli_real_escape_string($conn, $_POST['correo']);
    $rol = mysqli_real_escape_string($conn, $_POST['rol']);

    // 2. Creamos la sentencia SQL de actualización
    // IMPORTANTE: El WHERE id='$id' asegura que solo se cambie a ESE usuario
    $query = "UPDATE usuarios SET 
              nombre = '$nombre', 
              correo = '$correo', 
              rol = '$rol' 
              WHERE id = '$id'";

    // 3. Ejecutamos la consulta y verificamos si funcionó
    if (mysqli_query($conn, $query)) {
        // Si sale bien, regresamos a la gestión de usuarios con un mensaje de éxito
        header("Location: ../dashboard.php?seccion=gestion_usuarios&status=editado");
        exit();
    } else {
        // Si sale mal, mostramos el error de MySQL
        echo "Error al actualizar registro: " . mysqli_error($conn);
    }

} else {
    // Si alguien intenta entrar a este archivo sin presionar el botón, lo sacamos
    header("Location: ../dashboard.php");
    exit();
}
?>