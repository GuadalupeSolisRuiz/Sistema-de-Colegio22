<?php
session_start();
include 'db.php';

// Solo permitimos que entren si tienen el botón de actualizar
if (isset($_POST['btn_actualizar_status'])) {
    $id_cita = $_POST['id_cita'];
    $nuevo_estatus = $_POST['nuevo_estatus'];

    // Usamos UPDATE para cambiar el valor en la tabla
    $sql = "UPDATE citas_plantel SET estatus = '$nuevo_estatus' WHERE id = '$id_cita'";

    if (mysqli_query($conn, $sql)) {
        // Regresamos a la vista de gestión de citas con éxito
        header("Location: ../dashboard.php?seccion=gestion_citas&status=updated");
    } else {
        header("Location: ../dashboard.php?seccion=gestion_citas&error=db");
    }
    exit();
}
?>