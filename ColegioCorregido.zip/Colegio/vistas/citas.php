<?php
// Verificación de seguridad: Evita que se acceda directamente al archivo
if (!isset($conn)) {
    exit("Acceso denegado.");
}

$u_id = $_SESSION['usuario_id'];
?>

<div class="row g-4">
    <div class="col-md-5">
        <div class="card border-0 shadow-sm p-4">
            <h5 class="fw-bold text-purple mb-3">
                <i class="bi bi-calendar-plus me-2"></i>Agendar Cita al Plantel
            </h5>
            <form action="procesar_cita.php" method="POST">
                <div class="mb-3">
                    <label class="form-label">Motivo de la visita</label>
                    <select name="motivo" class="form-select" required>
                        <option value="">Seleccione una opción...</option>
                        <option value="Trámites Administrativos">Trámites Administrativos</option>
                        <option value="Soporte Técnico">Soporte Técnico</option>
                        <option value="Asesoría Académica">Asesoría Académica</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Fecha</label>
                    <input type="date" name="fecha" class="form-control" required min="<?php echo date('Y-m-d'); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Hora preferente</label>
                    <input type="time" name="hora" class="form-control" required>
                </div>
                <button type="submit" name="btn_cita" class="btn btn-purple w-100 text-white" style="background: var(--purple-primary);">
                    Enviar Solicitud
                </button>
            </form>
        </div>
    </div>

    <div class="col-md-7">
        <div class="card border-0 shadow-sm p-4">
            <h5 class="fw-bold text-purple mb-3">Mis Citas Solicitadas</h5>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Fecha y Hora</th>
                            <th>Motivo</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Busca la línea del SELECT y cámbiala por esta:
                        $sql_citas = "SELECT * FROM citas_plantel WHERE id_usuario = '$u_id' ORDER BY fecha_cita DESC";
                        $res_citas = mysqli_query($conn, $sql_citas);

                        if (mysqli_num_rows($res_citas) > 0) {
                            while ($c = mysqli_fetch_assoc($res_citas)) {
                                $estatus_class = ($c['estatus'] == 'Pendiente') ? 'bg-warning text-dark' : 'bg-success';
                                echo "<tr>
                                        <td>" . date('d/m/Y', strtotime($c['fecha_cita'])) . " - " . $c['hora_cita'] . "</td>
                                        <td>{$c['motivo']}</td>
                                        <td><span class='badge $estatus_class'>{$c['estatus']}</span></td>
                                      </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='3' class='text-center text-muted'>No tienes citas registradas.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>