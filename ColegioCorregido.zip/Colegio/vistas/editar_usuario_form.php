<?php
// 1. Verificamos que venga un ID por la URL
if (!isset($_GET['id'])) {
    echo "<script>window.location='dashboard.php?seccion=gestion_usuarios';</script>";
    exit();
}

$id_editar = mysqli_real_escape_string($conn, $_GET['id']);

// 2. Consultamos los datos de ese usuario específico
// Hacemos un JOIN para saber qué nombre de rol tiene actualmente
$sql = "SELECT * FROM usuarios WHERE id = '$id_editar'";
$res = mysqli_query($conn, $sql);
$usuario = mysqli_fetch_assoc($res);

// Si el usuario no existe, regresamos
if (!$usuario) {
    echo "Usuario no encontrado.";
    exit();
}
?>

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card border-0 shadow-sm mt-4">
                <div class="card-header bg-white border-0 py-3">
                    <h5 class="fw-bold text-purple mb-0">
                        <i class="bi bi-pencil-square me-2"></i>Editar Información de Usuario
                    </h5>
                </div>
                <div class="card-body p-4">
                    <form action="includes/editar_usuario.php" method="POST">
                        
                        <input type="hidden" name="id_usuario" value="<?php echo $usuario['id']; ?>">

                        <div class="mb-3">
                            <label class="form-label fw-bold">Nombre Completo</label>
                            <input type="text" name="nombre" class="form-control" 
                                   value="<?php echo $usuario['nombre']; ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Correo Electrónico</label>
                            <input type="email" name="correo" class="form-control" 
                                   value="<?php echo $usuario['correo']; ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Rol en el Sistema</label>
                            <select name="rol" class="form-select">
                                <option value="1" <?php echo ($usuario['rol'] == 1) ? 'selected' : ''; ?>>Sistemas (Admin)</option>
                                <option value="2" <?php echo ($usuario['rol'] == 2) ? 'selected' : ''; ?>>Maestro</option>
                                <option value="3" <?php echo ($usuario['rol'] == 3) ? 'selected' : ''; ?>>Alumno</option>
                            </select>
                        </div>

                        <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                            <a href="dashboard.php?seccion=gestion_usuarios" class="btn btn-light me-md-2">Cancelar</a>
                            <button type="submit" name="btn_actualizar" class="btn btn-purple px-4">
                                Guardar Cambios
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>