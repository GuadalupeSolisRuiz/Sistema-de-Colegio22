<?php if(isset($_GET['status'])): ?>
    <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i> 
        <?php 
            if($_GET['status'] == 'success') echo "¡Usuario registrado con éxito!";
            if($_GET['status'] == 'editado') echo "¡Usuario actualizado correctamente!";
            if($_GET['status'] == 'eliminado') echo "Usuario eliminado del sistema.";
        ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm p-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="fw-bold text-purple">Gestión de Usuarios</h5>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalUsuario">
            <i class="bi bi-plus-lg"></i> Nuevo Usuario
        </button>
    </div>
    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>Nombre</th>
                    <th>Correo</th>
                    <th>Rol</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Usamos la variable $row como en tu código original
                $query = "SELECT * FROM usuarios";
                $result = mysqli_query($conn, $query);
                while($row = mysqli_fetch_assoc($result)):
                    // Lógica para etiquetas de roles
                    $lbl_rol = ($row['rol']==1)?'Sistemas':(($row['rol']==2)?'Maestro':'Alumno');
                    $color = ($row['rol']==1)?'bg-dark':(($row['rol']==2)?'bg-primary':'bg-info');
                ?>
                <tr>
                    <td><?php echo $row['nombre']; ?></td>
                    <td><?php echo $row['correo']; ?></td>
                    <td><span class="badge <?php echo $color; ?>"><?php echo $lbl_rol; ?></span></td>
                    <td>
                        <a href="dashboard.php?seccion=editar_usuario&id=<?php echo $row['id']; ?>" 
                           class="btn btn-sm btn-outline-warning">
                           <i class="bi bi-pencil"></i>
                        </a>

                        <a href="includes/eliminar_usuario.php?id=<?php echo $row['id']; ?>" 
                           class="btn btn-sm btn-danger" 
                           onclick="return confirm('¿Seguro que deseas eliminar a este usuario?')">
                           <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'vistas/modal_usuario.php'; ?>