<nav class="navbar navbar-custom d-flex justify-content-between mb-4">
    <span class="badge bg-purple-light text-purple p-2">
        <i class="bi bi-shield-lock-fill me-1"></i> 
        Sesión: <span class="fw-bold"><?php echo $nombre_rol_texto; ?></span>
    </span>
    
    <div class="dropdown">
        <a href="#" class="d-flex align-items-center text-dark text-decoration-none dropdown-toggle" id="userMenu" data-bs-toggle="dropdown">
            <div class="avatar-circle-sm me-2">
                <?php echo $iniciales; ?>
            </div>
            <strong><?php echo $nombre_corto; ?></strong>
        </a>
        
        <ul class="dropdown-menu dropdown-menu-end shadow border-0 mt-2">
            <li class="px-3 py-2 border-bottom">
                <small class="text-muted d-block">Usuario:</small>
                <span class="fw-bold small"><?php echo $nombre_completo; ?></span>
            </li>
            <li><hr class="dropdown-divider"></li>
            <li>
                <a class="dropdown-item text-danger" href="includes/cerrar.php">
                    <i class="bi bi-box-arrow-right me-2"></i>Cerrar Sesión
                </a>
            </li>
        </ul>
    </div>
</nav>