<?php
session_start();
include 'includes/db.php';

// 1. Sanitización de entradas para evitar Inyección SQL
$correo = mysqli_real_escape_string($conn, $_POST['correo']);
$password_ingresado = $_POST['password'];

// 2. Procesamiento con MD5 (según tu requerimiento actual)
$password_md5 = md5($password_ingresado);

// 3. Consulta optimizada trayendo los 3 atributos de nombre
$query = "SELECT id, nombre, apellido_paterno, apellido_materno, rol, correo 
          FROM usuarios 
          WHERE correo = '$correo' AND password = '$password_md5' 
          LIMIT 1";

$resultado = mysqli_query($conn, $query);

if ($resultado && mysqli_num_rows($resultado) > 0) {
    $usuario = mysqli_fetch_assoc($resultado);
    
    // 4. Persistencia de datos en Sesión
    $_SESSION['usuario_id'] = $usuario['id'];
    $_SESSION['nombre'] = $usuario['nombre'];
    $_SESSION['apellido_paterno'] = $usuario['apellido_paterno'];
    $_SESSION['apellido_materno'] = $usuario['apellido_materno'];
    $_SESSION['rol'] = $usuario['rol'];
    $_SESSION['correo'] = $usuario['correo'];

    // 5. Generación de Variable de Interfaz (Nombre Completo)
    // Esto evita procesar concatenaciones en cada página del dashboard
    $_SESSION['nombre_completo'] = $usuario['nombre'] . " " . 
                                   $usuario['apellido_paterno'] . " " . 
                                   $usuario['apellido_materno'];

    // Redirección exitosa
    header("Location: dashboard.php");
    exit(); // Siempre usa exit() después de un header para detener la ejecución
} else {
    // Manejo de error de autenticación
    header("Location: login.php?error=datos_incorrectos");
    exit();
}
?>