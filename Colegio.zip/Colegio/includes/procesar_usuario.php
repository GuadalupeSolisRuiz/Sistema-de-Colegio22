<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $apellido_p = $_POST['apellido_paterno'];
    $apellido_m = $_POST['apellido_materno'];
    $correo = $_POST['correo'];
    $pass_md5 = md5($_POST['password']);
    $rol = $_POST['rol'];

    // Insertar en la base de datos con la variable md5
    $sql = "INSERT INTO usuarios (nombre, apellido_paterno, apellido_materno, correo, password, rol) 
            VALUES ('$nombre', '$apellido_p', '$apellido_m', '$correo', '$pass_md5', '$rol')";

    if (mysqli_query($conn, $sql)) {
        // Redirigir de vuelta al dashboard para no ver la pantalla blanca
        header("Location: ../dashboard.php?seccion=gestion_usuarios&status=success");
        exit();
    } else {
        echo "Error al registrar: " . mysqli_error($conn);
    }
}
?>