<?php
// 1. Incluir la conexión a la base de datos
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // 2. Recibir y limpiar los datos del formulario
    $nombre = mysqli_real_escape_string($conn, $_POST['nombre']);
    $ap_paterno = mysqli_real_escape_string($conn, $_POST['apellido_paterno']);
    $ap_materno = mysqli_real_escape_string($conn, $_POST['apellido_materno']);
    $correo = mysqli_real_escape_string($conn, $_POST['correo']);
    $rol = mysqli_real_escape_string($conn, $_POST['rol']);
    
    // 3. Encriptar la contraseña (importante por seguridad)
    $password = md5($_POST['password']); 

    // 4. Insertar en la base de datos
    // Asegúrate de que los nombres de las columnas coincidan con tu tabla MySQL
    $query = "INSERT INTO usuarios (nombre, apellido_paterno, apellido_materno, correo, password, rol) 
              VALUES ('$nombre', '$ap_paterno', '$ap_materno', '$correo', '$password', '$rol')";

    if (mysqli_query($conn, $query)) {
        // Redirigir con éxito
        header("Location: ../dashboard.php?seccion=gestion_usuarios&status=success");
    } else {
        // Mostrar error de SQL si falla
        echo "Error al registrar: " . mysqli_error($conn);
    }
} else {
    header("Location: ../dashboard.php");
}
?>