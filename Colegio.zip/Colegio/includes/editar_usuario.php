<?php
session_start();
include 'db.php'; // Conexión a la base de datos

// Verificamos que el formulario haya sido enviado por POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // 1. Recibimos y limpiamos los datos del formulario
    // Asegúrate que los 'name' coincidan con los de tu formulario de edición
    $id = mysqli_real_escape_string($conn, $_POST['id']); 
    $nombre = mysqli_real_escape_string($conn, $_POST['nombre']);
    $ap_paterno = mysqli_real_escape_string($conn, $_POST['apellido_paterno']);
    $ap_materno = mysqli_real_escape_string($conn, $_POST['apellido_materno']);
    $correo = mysqli_real_escape_string($conn, $_POST['correo']);
    $rol = mysqli_real_escape_string($conn, $_POST['rol']);

    // 2. Creamos la sentencia SQL incluyendo los nuevos campos
    $query = "UPDATE usuarios SET 
                nombre = '$nombre', 
                apellido_paterno = '$ap_paterno', 
                apellido_materno = '$ap_materno', 
                correo = '$correo', 
                rol = '$rol' 
              WHERE id = '$id'";

    // 3. Ejecutamos la consulta
    if (mysqli_query($conn, $query)) {
        // Si tiene éxito, redirigimos a la tabla con el estado 'editado'
        header("Location: ../dashboard.php?seccion=gestion_usuarios&status=editado");
        exit();
    } else {
        // Si hay un error, lo mostramos para depurar
        echo "Error al actualizar el registro: " . mysqli_error($conn);
    }

} else {
    // Si intentan acceder directamente al archivo, redirigimos al dashboard
    header("Location: ../dashboard.php");
    exit();
}
?>