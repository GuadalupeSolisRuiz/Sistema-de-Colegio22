<?php
// includes/consultas_dashboard.php

// 1. Verificación de Capa de Seguridad
// Si no hay sesión activa, bloqueamos el acceso inmediatamente
if(!isset($_SESSION['usuario_id'])) { 
    header("Location: login.php"); 
    exit();
}

// 2. Extracción de Identidad de Sesión
$id_user = $_SESSION['usuario_id'];

// 3. CONSULTA NORMALIZADA: Obtenemos los atributos atómicos del nombre y el rol 
// Seleccionamos específicamente las columnas necesarias para optimizar el buffer de memoria
$query_user = "SELECT u.id, u.nombre, u.apellido_paterno, u.apellido_materno, u.rol, u.correo, r.nombre_rol 
               FROM usuarios u 
               INNER JOIN roles r ON u.rol = r.id_rol 
               WHERE u.id = '$id_user' 
               LIMIT 1";

$res_user = mysqli_query($conn, $query_user);

if($res_user && mysqli_num_rows($res_user) > 0) {
    // 4. Mapeo de Datos en Arreglo Asociativo
    $datos_usuario = mysqli_fetch_assoc($res_user);
    
    // Variables de Control de Acceso
    $rol = $datos_usuario['rol']; 
    $nombre_rol_texto = $datos_usuario['nombre_rol']; 
    
    // 5. Lógica de Presentación (Frontend Logic)
    // Generamos las versiones del nombre para diferentes partes de la UI
    
    // Versión corta para el Sidebar (Nombre y Primer Apellido)
    $nombre_corto = $datos_usuario['nombre'] . " " . $datos_usuario['apellido_paterno'];
    
    // Versión completa para el Perfil
    $nombre_completo = $datos_usuario['nombre'] . " " . 
                       $datos_usuario['apellido_paterno'] . " " . 
                       $datos_usuario['apellido_materno'];
                       
    // Iniciales para el Avatar Dinámico
    $iniciales = strtoupper(substr($datos_usuario['nombre'], 0, 1) . substr($datos_usuario['apellido_paterno'], 0, 1));

} else {
    // Fallback de Seguridad: Si el ID de sesión no existe en la DB, invalidamos todo
    session_destroy();
    header("Location: login.php?error=sesion_invalida");
    exit();
}
?>