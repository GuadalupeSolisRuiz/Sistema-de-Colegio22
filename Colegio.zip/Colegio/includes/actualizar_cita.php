<?php
session_start();
include 'db.php';

if (isset($_POST['btn_actualizar'])) {
    // Escapamos los datos por seguridad
    $id_cita = mysqli_real_escape_string($conn, $_POST['id_cita']);
    $estatus = mysqli_real_escape_string($conn, $_POST['nuevo_estatus']);
    
    // Detectamos de qué sección viene el usuario
    $seccion_origen = isset($_POST['desde_seccion']) ? $_POST['desde_seccion'] : 'inicio';

    $query = "UPDATE citas_plantel SET estatus = '$estatus' WHERE id = '$id_cita'";

    if (mysqli_query($conn, $query)) {
        // REDIRECCIÓN CONTEXTUAL: Ahora te regresa a gestion_citas automáticamente
        header("Location: ../dashboard.php?seccion=" . $seccion_origen . "&status=actualizado");
        exit();
    } else {
        echo "Error al actualizar la cita: " . mysqli_error($conn);
    }
} else {
    header("Location: ../dashboard.php");
    exit();
}
?>