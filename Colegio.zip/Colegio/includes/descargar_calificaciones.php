<?php
include 'db.php';
session_start();

// Nombre del archivo con marca de tiempo
$filename = "Reporte_Calificaciones_" . date('d-m-Y_His') . ".csv";

// Configuración de cabeceras para descarga
header('Content-Type: text/csv; charset=latin1');
header('Content-Disposition: attachment; filename="' . $filename . '"');

$output = fopen('php://output', 'w');

// Encabezados de las columnas
fputcsv($output, array('Alumno', 'Parcial 1', 'Parcial 2', 'Promedio'));

// Consulta de datos
$query = "SELECT u.nombre, u.apellido_paterno, u.apellido_materno, c.parcial1, c.parcial2 
          FROM calificaciones c 
          INNER JOIN usuarios u ON c.id_alumno = u.id 
          ORDER BY u.apellido_paterno ASC";

$result = mysqli_query($conn, $query);

while ($row = mysqli_fetch_assoc($result)) {
    $promedio = ($row['parcial1'] + $row['parcial2']) / 2;
    $nombre_completo = $row['apellido_paterno'] . " " . $row['apellido_materno'] . " " . $row['nombre'];
    
    fputcsv($output, array(
        $nombre_completo,
        $row['parcial1'],
        $row['parcial2'],
        number_format($promedio, 1)
    ));
}

fclose($output);
exit();
?>