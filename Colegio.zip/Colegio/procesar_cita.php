<?php
session_start();
// Si el archivo está en la raíz, esta ruta es correcta
include 'includes/db.php'; 

if (isset($_POST['btn_cita'])) {
    // Validamos que exista la sesión para evitar el error "Undefined variable $u_id"
    if(!isset($_SESSION['usuario_id'])){
        exit("Sesión no iniciada.");
    }

    $id_user = $_SESSION['usuario_id'];
    $motivo  = mysqli_real_escape_string($conn, $_POST['motivo']); 
    $fecha   = $_POST['fecha'];
    $hora    = $_POST['hora'];

    // Agregamos el campo 'estatus' con valor 'Pendiente' para que aparezca correctamente en la tabla
    $query = "INSERT INTO citas_plantel (id_usuario, motivo, fecha_cita, hora_cita, estatus) 
              VALUES ('$id_user', '$motivo', '$fecha', '$hora', 'Pendiente')";

    if (mysqli_query($conn, $query)) {
        // Redirección al dashboard con la sección activa para que el alumno vea su cita de inmediato
        header("Location: dashboard.php?seccion=cita_plantel&status=ok");
        exit(); // Siempre usa exit después de un header Location
    } else {
        echo "Error al registrar la cita: " . mysqli_error($conn);
    }
}
?>