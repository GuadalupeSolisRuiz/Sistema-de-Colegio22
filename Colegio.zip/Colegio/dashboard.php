<?php
// 1. Inicialización obligatoria de sesión
session_start();

// 2. Filtro de seguridad: Si no hay sesión, regresa al login
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

// 3. Carga de conexión a base de datos
include 'includes/db.php'; 

// 4. Variables globales de sesión
$u_id = $_SESSION['usuario_id']; 
$rol  = $_SESSION['rol'];

// 5. Carga de consultas para el Navbar
include 'includes/consultas_dashboard.php'; 

// 6. Determinar la sección actual
$seccion = isset($_GET['seccion']) ? $_GET['seccion'] : 'inicio';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Colegio Inglés | Panel de Control</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="assets/css/diseño.css">
</head>
<body>
<div class="d-flex">
    <?php include 'complementos/sidebar.php'; ?>

    <div class="main-content w-100" style="background-color: #f8f9fa; min-height: 100vh;">
        <?php include 'complementos/navbar.php'; ?>

        <div class="container-fluid py-4">
            <?php
            // --- ENRUTADOR DINÁMICO ---
            switch ($seccion) {
                case 'gestion_usuarios':
                    if($rol == 1) { 
                        include 'vistas/usuarios.php'; 
                    } else { 
                        echo "<div class='alert alert-danger'>No tienes permisos para acceder.</div>"; 
                    }
                    break;

                case 'editar_usuario':
                    if($rol == 1) { 
                        include 'vistas/editar_usuario_form.php'; 
                    }
                    break;

                case 'captura':
                    if($rol == 1 || $rol == 2) { 
                        include 'vistas/captura_notas.php'; 
                    }
                    break;

                case 'gestion_citas':
                case 'cita_plantel': 
                    include 'vistas/gestion_citas.php'; 
                    break;

                case 'inicio':
                default:
                    if ($rol == 1) { 
                        include 'vistas/inicio_admin.php'; 
                    } else if ($rol == 2) { 
                        include 'vistas/inicio_maestro.php'; 
                    } else { 
                        include 'vistas/inicio_alumno.php'; 
                    }
                    break;
            }
            ?>
        </div>
    </div>
</div>

<?php 
if($seccion == 'gestion_usuarios') {
    include 'vistas/modal_usuario.php'; 
}
?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>