<?php 
// Verificación de seguridad: Solo el Admin (rol 1) accede a esta vista
if ($rol != 1) {
    echo "<div class='alert alert-danger'>Acceso restringido.</div>";
    exit;
}
?>

<?php if(isset($_GET['status'])): ?>
    <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm animate__animated animate__fadeIn" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i> 
        <?php 
            if($_GET['status'] == 'success') echo "¡Usuario registrado con éxito!";
            if($_GET['status'] == 'editado') echo "¡Usuario actualizado correctamente!";
            if($_GET['status'] == 'eliminado') echo "Usuario eliminado del sistema.";
        ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h5 class="fw-bold text-purple mb-0">Gestión de Usuarios</h5>
            <small class="text-muted">Administración de personal y alumnado</small>
        </div>
        <button class="btn btn-purple text-white shadow-sm" data-bs-toggle="modal" data-bs-target="#modalUsuario" style="background: var(--purple-primary);">
            <i class="bi bi-person-plus-fill me-2"></i>Nuevo Usuario
        </button>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead class="table-light">
                <tr class="small text-uppercase">
                    <th>ID</th>
                    <th>Nombre(s)</th>
                    <th>Apellido Paterno</th>
                    <th>Apellido Materno</th>
                    <th>Correo</th>
                    <th>Rol</th>
                    <th class="text-center">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Consulta con JOIN para traer el nombre del rol
                $query = "SELECT u.*, r.nombre_rol 
                          FROM usuarios u 
                          JOIN roles r ON u.rol = r.id_rol 
                          ORDER BY u.id DESC";
                $res = mysqli_query($conn, $query);
                
                while($row = mysqli_fetch_assoc($res)): 
                    $badge_class = ($row['rol'] == 1) ? 'bg-dark' : (($row['rol'] == 2) ? 'bg-primary' : 'bg-info text-dark');
                ?>
                <tr>
                    <td class="fw-bold text-muted"><?php echo $row['id']; ?></td>
                    <td><?php echo $row['nombre']; ?></td>
                    <td><?php echo $row['apellido_paterno']; ?></td>
                    <td><?php echo $row['apellido_materno']; ?></td>
                    <td><?php echo $row['correo']; ?></td>
                    <td><span class="badge <?php echo $badge_class; ?>"><?php echo $row['nombre_rol']; ?></span></td>
                    <td class="text-center">
                        <div class="btn-group shadow-sm">
                            <a href="dashboard.php?seccion=editar_usuario&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-warning" title="Editar">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <a href="includes/eliminar_usuario.php?id=<?php echo $row['id']; ?>" 
                               class="btn btn-sm btn-outline-danger" 
                               onclick="return confirm('¿Estás seguro de eliminar a este usuario?')" title="Eliminar">
                                <i class="bi bi-trash"></i>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>