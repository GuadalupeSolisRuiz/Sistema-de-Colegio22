<?php
// Verificación de seguridad: Evita que se acceda directamente al archivo
if (!isset($conn)) {
    exit("Acceso denegado.");
}

$u_id = $_SESSION['usuario_id'];
?>

<div class="row g-4">
    <div class="col-md-5">
        <div class="card border-0 shadow-sm p-4">
            <h5 class="fw-bold text-purple mb-3">
                <i class="bi bi-calendar-plus me-2"></i>Agendar Cita al Plantel
            </h5>
            <form action="procesar_cita.php" method="POST">
                <div class="mb-3">
                    <label class="form-label">Motivo de la visita</label>
                    <select name="motivo" class="form-select" required>
                        <option value="">Seleccione una opción...</option>
                        <option value="Trámites Administrativos">Trámites Administrativos</option>
                        <option value="Soporte Técnico">Soporte Técnico</option>
                        <option value="Asesoría Académica">Asesoría Académica</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Fecha</label>
                    <input type="date" name="fecha" class="form-control" required min="<?php echo date('Y-m-d'); ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Hora preferente</label>
                    <input type="time" name="hora" class="form-control" required>
                </div>
               <button type="submit" name="btn_cita" class="btn w-100 text-white shadow-sm" 
        style="background-color: #6f42c1 !important; border-color: #6f42c1 !important;">
    <i class="bi bi-calendar-check me-2"></i>Enviar Solicitud
</button>
            </form>
        </div>
    </div>

    <div class="col-md-7">
    <div class="card border-0 shadow-sm p-4">
        <h5 class="fw-bold text-purple mb-3">Mis Citas Solicitadas</h5>
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th>Alumno</th> <th>Fecha y Hora</th>
                        <th>Motivo</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Consulta avanzada con JOIN para obtener el nombre completo
                    $sql_citas = "SELECT c.*, u.nombre, u.apellido_paterno, u.apellido_materno 
                                  FROM citas_plantel c 
                                  INNER JOIN usuarios u ON c.id_usuario = u.id 
                                  WHERE c.id_usuario = '$u_id' 
                                  ORDER BY c.fecha_cita DESC";
                    
                    $res_citas = mysqli_query($conn, $sql_citas);

                    if (mysqli_num_rows($res_citas) > 0) {
                        while ($c = mysqli_fetch_assoc($res_citas)) {
                            // Definimos el color del badge según el estatus
                            $estatus_class = ($c['estatus'] == 'Pendiente') ? 'bg-warning text-dark' : 'bg-success text-white';
                            
                            // Concatenación del nombre legal completo
                            $nombre_full = $c['nombre'] . " " . $c['apellido_paterno'] . " " . $c['apellido_materno'];
                            
                            echo "<tr>
                                    <td class='fw-bold small text-muted'>$nombre_full</td>
                                    <td><i class='bi bi-clock me-1'></i>" . date('d/m/Y', strtotime($c['fecha_cita'])) . " - " . $c['hora_cita'] . "</td>
                                    <td>{$c['motivo']}</td>
                                    <td><span class='badge $estatus_class'>{$c['estatus']}</span></td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4' class='text-center text-muted p-4'>No tienes citas registradas.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>