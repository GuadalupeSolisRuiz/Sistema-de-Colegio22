<div class="modal fade" id="modalUsuario" tabindex="-1" aria-labelledby="modalUsuarioLabel" aria-hidden="true">
    <div class="modal-dialog shadow-lg">
        <form action="includes/procesar_usuario.php" method="POST" class="modal-content border-0">
            <div class="modal-header bg-purple text-white" style="background-color: #6f42c1 !important;">
                <h5 class="modal-title" id="modalUsuarioLabel">
                    <i class="bi bi-person-plus me-2"></i>Registrar Nuevo Miembro
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label small fw-bold">Nombre(s)</label>
                    <input type="text" name="nombre" class="form-control shadow-none" placeholder="Ej. Diego" required>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label small fw-bold">Apellido Paterno</label>
                        <input type="text" name="apellido_paterno" class="form-control shadow-none" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label small fw-bold">Apellido Materno</label>
                        <input type="text" name="apellido_materno" class="form-control shadow-none" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold">Correo Institucional</label>
                    <input type="email" name="correo" class="form-control shadow-none" placeholder="usuario@escuela.edu" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold">Contraseña</label>
                    <input type="password" name="password" class="form-control shadow-none" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-bold">Asignar Rol</label>
                    <select name="rol" class="form-select shadow-none" required>
                        <option value="1">Administrador</option>
                        <option value="2">Maestro</option>
                        <option value="3">Alumno</option>
                    </select>
                </div>
            </div>
            <div class="modal-footer border-0">
                <button type="submit" class="btn text-white w-100 py-2 shadow-sm" style="background-color: #6f42c1;">
                    <i class="bi bi-save me-2"></i>Guardar Usuario
                </button>
            </div>
        </form>
    </div>
</div>