<div class="card border-0 shadow-sm p-4">
    <h5 class="fw-bold text-purple"><i class="bi bi-pencil-fill me-2"></i> Capturar Calificaciones</h5>
    <form action="includes/procesar_notas.php" method="POST" class="row g-3 mt-2">
        <div class="col-md-4">
            <label class="form-label">Seleccionar Alumno</label>
            <select name="id_alumno" class="form-select shadow-none" required>
                <option value="">Seleccione...</option>
                <?php
                $res_alumnos = mysqli_query($conn, "SELECT id, nombre, apellido_paterno, apellido_materno FROM usuarios WHERE rol = 3 ORDER BY apellido_paterno ASC");
                while($al = mysqli_fetch_assoc($res_alumnos)){
                    $nombre_full = $al['apellido_paterno'] . " " . $al['apellido_materno'] . " " . $al['nombre'];
                    echo "<option value='".$al['id']."'>".$nombre_full."</option>";
                }
                ?>
            </select>
        </div>
        <div class="col-md-2">
            <label class="form-label">Parcial 1</label>
            <input type="number" step="0.1" name="p1" class="form-control shadow-none" min="0" max="10" required>
        </div>
        <div class="col-md-2">
            <label class="form-label">Parcial 2</label>
            <input type="number" step="0.1" name="p2" class="form-control shadow-none" min="0" max="10" required>
        </div>
        <div class="col-md-1 d-flex align-items-end">
            <button type="submit" name="btn_subir_nota" class="btn btn-purple w-100 text-white" style="background:#6f42c1">
                <i class="bi bi-save"></i>
            </button>
        </div>
    </form>
</div>

<div class="card border-0 shadow-sm p-4 mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="fw-bold text-muted m-0">Últimos registros</h5>
        <a href="includes/descargar_calificaciones.php" class="btn btn-sm btn-outline-success">
            <i class="bi bi-file-earmark-excel me-1"></i> Descargar Reporte
        </a>
    </div>
    
    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead>
                <tr class="text-muted small">
                    <th>Alumno</th>
                    <th class="text-center">P1</th>
                    <th class="text-center">P2</th>
                    <th class="text-center">Promedio</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql_h = "SELECT c.*, u.nombre, u.apellido_paterno, u.apellido_materno 
                          FROM calificaciones c 
                          INNER JOIN usuarios u ON c.id_alumno = u.id 
                          ORDER BY c.id DESC LIMIT 10";
                          
                $res_h = mysqli_query($conn, $sql_h);
                while($h = mysqli_fetch_assoc($res_h)):
                    // Asegúrate que los nombres de columna coincidan con tu BD (parcial1, parcial2 o p1, p2)
                    $p1 = $h['parcial1']; 
                    $p2 = $h['parcial2'];
                    $promedio = ($p1 + $p2) / 2;
                    
                    $alumno_nombre = $h['apellido_paterno'] . " " . $h['apellido_materno'] . " " . $h['nombre'];
                    
                    // Lógica de color: Rojo si es menor a 6.0 (Estilo Colegio Inglés)
                    $badge_class = ($promedio < 6) ? 'bg-danger text-white' : 'bg-light text-dark';
                ?>
                <tr>
                    <td class="fw-bold"><?php echo $alumno_nombre; ?></td>
                    <td class="text-center"><?php echo number_format($p1, 1); ?></td>
                    <td class="text-center"><?php echo number_format($p2, 1); ?></td>
                    <td class="text-center">
                        <span class="badge <?php echo $badge_class; ?> rounded-pill px-3">
                            <?php echo number_format($promedio, 1); ?>
                        </span>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>