<?php
error_reporting(0);
if (!isset($conn)) { exit; }

$u_id = $_SESSION['usuario_id'];
$rol  = $_SESSION['rol'];

// Consulta de citas según rol para el contador del dashboard
if ($rol == 1) {
    // Admin ve el total de citas pendientes de TODO el plantel
    $sql_citas_m = "SELECT COUNT(*) as total FROM citas_plantel WHERE estatus = 'Pendiente'";
} else {
    // Maestro ve solo las asesorías académicas
    $sql_citas_m = "SELECT COUNT(*) as total FROM citas_plantel WHERE motivo = 'Asesoría Académica' AND estatus = 'Pendiente'";
}

$res_citas_m = mysqli_query($conn, $sql_citas_m);

// VALIDACIÓN CRÍTICA: Si la consulta falló, evitamos el crash
if ($res_citas_m) {
    $citas_data = mysqli_fetch_assoc($res_citas_m);
    $total_pendientes = $citas_data['total'];
} else {
    $total_pendientes = 0; // Valor por defecto si hay error en SQL
}
?>
<div class="row g-4">
        <div class="col-md-4">
            <div class="card border-0 shadow-sm p-3 border-start border-4 border-success">
                <div class="d-flex align-items-center">
                    <div class="badge bg-success-light p-3 rounded-circle me-3">
                        <i class="bi bi-journal-check text-success fs-4"></i>
                    </div>
                    <div>
                        <h6 class="text-muted small mb-1">Estatus Académico</h6>
                        <h4 class="fw-bold mb-0 text-success">Regular</h4>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm p-3 border-start border-4 border-warning">
                <div class="d-flex align-items-center">
                    <div class="badge bg-warning-light p-3 rounded-circle me-3">
                        <i class="bi bi-calendar-event text-warning fs-4"></i>
                    </div>
                    <div>
                        <h6 class="text-muted small mb-1">Citas Pendientes</h6>
                        <h4 class="fw-bold mb-0"><?php echo $citas_data['total']; ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <div class="row g-4">
        <div class="col-md-8">
            <div class="card border-0 shadow-sm p-4">
                <h5 class="fw-bold text-purple mb-3">
                    <i class="bi bi-grid-1x2-fill me-2"></i>Historial Académico
                </h5>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr class="small text-muted">
                                <th>Materia</th>
                                <th class="text-center">P1</th>
                                <th class="text-center">P2</th>
                                <th class="text-center">Promedio</th>
                                <th class="text-center">Estatus</th>
                            </tr>
                        </thead>
                        <tbody>
                            </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <?php include 'vistas/avisos_usuario.php'; ?>
        </div>
    </div>


<style>
/* Estilos extra para que luzca profesional */
.bg-purple-light { background-color: rgba(111, 66, 193, 0.1); }
.bg-success-light { background-color: rgba(40, 167, 69, 0.1); }
.bg-warning-light { background-color: rgba(255, 193, 7, 0.1); }
.border-purple { border-color: var(--purple-primary) !important; }
</style>