<?php
if (!isset($conn)) { exit; }

// Consultas globales para el Admin
$res_alumnos = mysqli_query($conn, "SELECT COUNT(*) as total FROM usuarios WHERE rol = 3");
$total_alumnos = mysqli_fetch_assoc($res_alumnos)['total'];

$res_maestros = mysqli_query($conn, "SELECT COUNT(*) as total FROM usuarios WHERE rol = 2");
$total_maestros = mysqli_fetch_assoc($res_maestros)['total'];

$res_citas = mysqli_query($conn, "SELECT COUNT(*) as total FROM citas_plantel WHERE estatus = 'Pendiente'");
$total_citas = mysqli_fetch_assoc($res_citas)['total'];
?>

<div class="animate__animated animate__fadeIn">
    <h3 class="fw-bold text-dark mb-4">Panel de Control: <span class="text-purple">Administrador</span></h3>

    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card border-0 shadow-sm p-3 border-start border-4 border-primary">
                <div class="d-flex align-items-center">
                    <div class="badge bg-primary bg-opacity-10 p-3 rounded-circle me-3">
                        <i class="bi bi-people-fill text-primary fs-4"></i>
                    </div>
                    <div>
                        <h6 class="text-muted small mb-1">Alumnos Totales</h6>
                        <h4 class="fw-bold mb-0"><?php echo $total_alumnos; ?></h4>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm p-3 border-start border-4 border-purple">
                <div class="d-flex align-items-center">
                    <div class="badge bg-purple-light p-3 rounded-circle me-3">
                        <i class="bi bi-person-badge-fill text-purple fs-4"></i>
                    </div>
                    <div>
                        <h6 class="text-muted small mb-1">Docentes Activos</h6>
                        <h4 class="fw-bold mb-0"><?php echo $total_maestros; ?></h4>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card border-0 shadow-sm p-3 border-start border-4 border-warning">
                <div class="d-flex align-items-center">
                    <div class="badge bg-warning bg-opacity-10 p-3 rounded-circle me-3">
                        <i class="bi bi-calendar-check text-warning fs-4"></i>
                    </div>
                    <div>
                        <h6 class="text-muted small mb-1">Citas Pendientes</h6>
                        <h4 class="fw-bold mb-0"><?php echo $total_citas; ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-md-8">
            <div class="card border-0 shadow-sm p-4">
                <h5 class="fw-bold text-purple mb-4">Gestión de Sistema</h5>
                <div class="row g-3">
                    <div class="col-6 col-sm-4">
                        <a href="dashboard.php?seccion=gestion_usuarios" class="btn btn-light w-100 py-3 shadow-sm border-0">
                            <i class="bi bi-person-plus d-block fs-2 text-purple mb-2"></i>
                            <span class="small fw-bold">Usuarios</span>
                        </a>
                    </div>
                    <div class="col-6 col-sm-4">
                        <a href="dashboard.php?seccion=gestion_citas" class="btn btn-light w-100 py-3 shadow-sm border-0">
                            <i class="bi bi-calendar3 d-block fs-2 text-primary mb-2"></i>
                            <span class="small fw-bold">Citas</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
    <?php 
        // Esta ruta sube un nivel o busca directamente en vistas
        $ruta_avisos = 'vistas/avisos_usuario.php'; 
        
        if (file_exists($ruta_avisos)) {
            include $ruta_avisos;
        } else {
            // Si el archivo está en la raíz de vistas, intenta esto:
            include 'avisos_usuario.php';
        }
    ?>
</div>
    </div>
</div>

<style>
.bg-purple-light { background-color: rgba(111, 66, 193, 0.1); }
.text-purple { color: var(--purple-primary) !important; }
.border-purple { border-color: var(--purple-primary) !important; }
</style>