<?php
// Verificación de seguridad: solo si se incluye desde el dashboard
if (!isset($_SESSION['rol'])) { exit; }

$rol_actual = $_SESSION['rol'];
?>

<div class="card border-0 shadow-sm p-4 text-white mb-3" style="background: var(--purple-primary); border-radius: 15px;">
    <h6 class="fw-bold mb-3">
        <i class="bi bi-megaphone-fill me-2"></i>Avisos Recientes
    </h6>
    <hr class="border-light opacity-50">
    
    <div class="small">
        <?php if ($rol_actual == 1): // Administrador ?>
            <p class="mb-0">Hay <strong>0 solicitudes</strong> de usuarios pendientes de aprobación en el sistema.</p>
        <?php elseif ($rol_actual == 2): // Maestro ?>
            <p class="mb-2">Recuerde que el cierre de actas para las <strong>calificaciones</strong> es el próximo viernes.</p>
            <p class="mb-0 border-top border-light pt-2 opacity-75" style="font-size: 0.75rem;">
                <i class="bi bi-info-circle me-1"></i> Tiene 0 asesorías pendientes esta semana.
            </p>
        <?php else: // Alumno ?>
            <p class="mb-0">No olvides realizar tu <strong>evaluación docente</strong> antes del viernes para liberar tu reinscripción.</p>
        <?php endif; ?>
    </div>
</div>

<div class="card border-0 shadow-sm p-4 bg-white" style="border-radius: 15px;">
    <h6 class="text-secondary fw-bold mb-3">Información de Usuario</h6>
    
    <div class="mb-2">
        <label class="text-muted small d-block">Correo:</label>
        <span class="small fw-bold text-dark">
            <?php echo isset($_SESSION['correo']) ? $_SESSION['correo'] : 'admin@colegio.com'; ?>
        </span>
    </div>
    
    <div>
        <label class="text-muted small d-block">Matrícula / ID:</label>
        <span class="small fw-bold text-dark">
            #<?php echo $_SESSION['usuario_id']; ?>
        </span>
    </div>
</div>