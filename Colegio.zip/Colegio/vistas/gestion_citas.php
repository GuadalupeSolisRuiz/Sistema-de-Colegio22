<?php
// 1. Verificación de seguridad: heredamos la conexión del dashboard
if (!isset($conn)) { exit("Acceso denegado."); }

$u_id = $_SESSION['usuario_id']; 
$rol  = $_SESSION['rol']; 

// 2. Lógica de consulta (JOIN para obtener nombres de alumnos y filtrar por rol)
if ($rol == 1) {
    // El Administrador ve todas las citas
    $sql_citas = "SELECT c.*, u.nombre, u.apellido_paterno 
                  FROM citas_plantel c 
                  INNER JOIN usuarios u ON c.id_usuario = u.id 
                  ORDER BY c.fecha_cita DESC";
} else if ($rol == 2) {
    // El Maestro solo ve las de "Asesoría Académica"
    $sql_citas = "SELECT c.*, u.nombre, u.apellido_paterno 
                  FROM citas_plantel c 
                  INNER JOIN usuarios u ON c.id_usuario = u.id 
                  WHERE c.motivo = 'Asesoría Académica' 
                  ORDER BY c.fecha_cita DESC";
} else {
    // El Alumno solo ve sus propias citas
    $sql_citas = "SELECT * FROM citas_plantel WHERE id_usuario = '$u_id' ORDER BY fecha_cita DESC";
}

$res_citas = mysqli_query($conn, $sql_citas);
?>

<div class="row g-4 animate__animated animate__fadeIn">
    
    <?php if ($rol == 3): ?>
    <div class="col-md-5">
        <div class="card border-0 shadow-sm p-4">
            <h5 class="fw-bold text-purple mb-3"><i class="bi bi-calendar-plus me-2"></i>Nueva Cita</h5>
            <form action="procesar_cita.php" method="POST">
                <div class="mb-3">
                    <label class="form-label small fw-bold">Motivo</label>
                    <select name="motivo" class="form-select shadow-none" required>
                        <option value="Asesoría Académica">Asesoría Académica</option>
                        <option value="Trámites Administrativos">Trámites Administrativos</option>
                        <option value="Soporte Técnico">Soporte Técnico</option>
                    </select>
                </div>
                <div class="row">
                    <div class="col-6 mb-3"><input type="date" name="fecha" class="form-control" required></div>
                    <div class="col-6 mb-3"><input type="time" name="hora" class="form-control" required></div>
                </div>
                <button type="submit" name="btn_cita" class="btn btn-purple w-100 text-white shadow-sm" style="background-color: #6f42c1 !important;">
                    <i class="bi bi-calendar-check me-2"></i>Enviar Solicitud
                </button>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <div class="<?php echo ($rol == 3) ? 'col-md-7' : 'col-12'; ?>">
        <div class="card border-0 shadow-sm p-4">
            <h5 class="fw-bold text-purple mb-3">
                <?php echo ($rol == 2) ? 'Asesorías Académicas' : 'Mis Citas'; ?>
            </h5>
            
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light small">
                        <tr>
                            <?php if($rol == 1 || $rol == 2): ?> <th>Alumno</th> <?php endif; ?>
                            <th>Fecha / Hora</th>
                            <th>Motivo</th>
                            <th class="text-center">Estatus</th>
                            <?php if($rol == 1 || $rol == 2): ?> <th class="text-center">Acción</th> <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if ($res_citas && mysqli_num_rows($res_citas) > 0):
                            while ($c = mysqli_fetch_assoc($res_citas)): 
                                $badge = ($c['estatus'] == 'Pendiente') ? 'bg-warning text-dark' : 'bg-success text-white';
                        ?>
                        <tr>
                            <?php if($rol == 1 || $rol == 2): ?>
                                <td class="small"><b><?php echo $c['nombre']." ".$c['apellido_paterno']; ?></b></td>
                            <?php endif; ?>
                            
                            <td class="small">
                                <b><?php echo date('d/m/Y', strtotime($c['fecha_cita'])); ?></b><br>
                                <span class="text-muted" style="font-size:0.7rem;"><?php echo $c['hora_cita']; ?></span>
                            </td>
                            <td class="small"><?php echo $c['motivo']; ?></td>
                            <td class="text-center">
                                <span class="badge <?php echo $badge; ?> rounded-pill px-3"><?php echo $c['estatus']; ?></span>
                            </td>

                            <?php if($rol == 1 || ($rol == 2 && $c['motivo'] == 'Asesoría Académica')): ?>
                            <td class="text-center">
                                <form action="includes/actualizar_cita.php" method="POST" class="d-flex gap-1 justify-content-center">
                                    <input type="hidden" name="id_cita" value="<?php echo $c['id']; ?>">
                                    <input type="hidden" name="desde_seccion" value="gestion_citas">
                                    
                                    <select name="nuevo_estatus" class="form-select form-select-sm py-0 shadow-none" style="font-size: 0.75rem; width: 110px;">
                                        <option value="Pendiente" <?php if($c['estatus']=='Pendiente') echo 'selected'; ?>>Pendiente</option>
                                        <option value="Completada" <?php if($c['estatus']=='Completada') echo 'selected'; ?>>Completada</option>
                                    </select>
                                    <button type="submit" name="btn_actualizar" class="btn btn-sm btn-purple text-white py-0 px-2" style="background-color: #6f42c1 !important;">
                                      <i class="bi bi-check2"></i>
                                    </button>
                                </form>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php 
                            endwhile; 
                        else: 
                        ?>
                        <tr>
                            <td colspan="5" class="text-center py-4 text-muted small">No hay citas registradas.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>